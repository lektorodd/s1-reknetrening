import{l as o,a as r}from"../chunks/BlZR4-k3.js";export{o as load_css,r as start};
